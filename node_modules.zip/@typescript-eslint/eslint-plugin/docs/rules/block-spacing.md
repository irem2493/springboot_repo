---
displayed_sidebar: rulesSidebar
---

:::danger Deprecated

This rule has been moved to the [ESLint stylistic plugin](https://eslint.style).
See [#8072](https://github.com/typescript-eslint/typescript-eslint/issues/8072) and [#8074](https://github.com/typescript-eslint/typescript-eslint/issues/8074) for more information.

:::

<!-- This doc file has been left on purpose to help direct people to the stylistic plugin.

Note that there is no actual way to get to this page in the normal navigation,
so end-users will only be able to get to this page from the search bar. -->
