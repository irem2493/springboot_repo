import {
  require_react_dom
} from "./chunk-HCIN4FJ4.js";
import "./chunk-REFQX4J5.js";
export default require_react_dom();
